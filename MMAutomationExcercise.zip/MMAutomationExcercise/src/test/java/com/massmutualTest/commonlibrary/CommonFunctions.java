package com.massmutualTest.commonlibrary;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import com.massmutualTest.utilities.LoadProperties;

public class CommonFunctions extends LoadProperties {

	/**
	 * Below method is for list value(s) comparision
	 * @param listvalues
	 * @param Data
	 * @param splitBy
	 * @return true/false
	 * @author Purushotham
	 */
	public static boolean compareListAndStringArrays(List<String> listvalues, String Data, String splitBy) {
		String[] elementLists = Data.split(splitBy);
		String Result = "";
		boolean flag = true;
		try {
			for (int i = 0; i < listvalues.size(); i++) {
				if (elementLists[i].equals(" ")) {
					elementLists[i] = "";
				}
				if (!elementLists[i].trim().equals(listvalues.get(i).trim())) {
					Result = Result + "," + listvalues.get(i);
					flag = false;
				}
			}
			if (flag) {
				Reporter.log("Matched Options are" + Data, true);
			} else {
				Reporter.log("Below data" + Result + "is Not Matched", false);
			}
		} catch (Exception e) {
			Reporter.log("Below data" + Result + "is Not Matched", false);
		}
		return flag;
	}

	/**
	 * following method is for replacing a character from a given string
	 * @author Purushotham
	 */
	public static String replacevalue(String strdata, String fromChar, String toCharacter) {
		String strfinal = null;
		try {
			strfinal = strdata.replace(fromChar, toCharacter);
		} catch (Exception e) {
			Reporter.log("value is not possible to replace", false);
		}
		return strfinal;
	}
	
	/**
	 * following method is to capture and save the screenshots
	 * @param driver
	 * @author Purushotham
	 */
	public void captureScreenShot(WebDriver driver) {
		File screenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			String timeStamp = getTimeStamp();
			String location = getScreenshotLocation();
			String screenShotLocation = location + timeStamp + ".png";
			FileUtils.copyFile(screenShot, new File(screenShotLocation));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * following method is to capture the current time stamp
	 * @return
	 * @author Purushotham
	 */
	public String getTimeStamp() {
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		String currentTimeStamp = dateFormat.format(date);
		return currentTimeStamp;
	}

}
