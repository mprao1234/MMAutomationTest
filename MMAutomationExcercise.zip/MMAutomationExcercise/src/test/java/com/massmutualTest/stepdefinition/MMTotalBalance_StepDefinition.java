package com.massmutualTest.stepdefinition;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MMTotalBalance_StepDefinition extends MMBaseTest_SetpDefinition {

	@When("User is on the valuelist screen")
	public void user_is_on_the_valuelist_screen() {
		valuesPage.navigateToValuePage();
	}

	@Then("User should view correct count of values and lable as {string} on the screen")
	public void user_should_view_correct_count_of_values_and_label(String labelstext) {
		valuesPage.verifyCountAndlabelsName(labelstext);
	}

	@Then("Verify values on the screen should be greater than {int}")
	public void verify_values_on_the_screen_should_be_greater_than_zero(Integer inputValue) {
		valuesPage.verifyValueGreaterthanZero(inputValue);
	}

	@Then("Verify value formate as currency for all amounts")
	public void verify_value_formate_as_currency_for_all_ammount() {
		valuesPage.CheckCurrencyFormat();
	}

	@Then("Verify total balance match aginst the sum of the values_present")
	public void verify_total_balance_match_aginst_the_sum_of_the_values_present() {
		valuesPage.verifySumOfBalance();
	}
}
