package com.massmutualTest.stepdefinition;

import io.cucumber.java.en.Given;

public class Background_StepDefinition extends MMBaseTest_SetpDefinition {

	@Given("Open browser and launch application")
	public void reading_data_from_proerties_file_and_launching_browser_and_exercise_application() {
		webDriverConfig.launchApplication();
	}
}
