package com.massmutualTest.stepdefinition;

import com.massmutualTest.pages.ListPage;
import com.massmutualTest.utilities.WebDriverConfig;

public class MMBaseTest_SetpDefinition {
	
	protected WebDriverConfig webDriverConfig= new WebDriverConfig();
	protected ListPage valuesPage=new ListPage();
}
