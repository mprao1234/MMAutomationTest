package com.massmutualTest.testrunner;

import org.junit.runner.RunWith;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		
		features = "featureFile/VerifyTotalBalance.feature",
		glue = {"com.massmutualTest.stepdefinition","com.massmutualTest.utilities"},
		plugin = {"pretty","html:target/HtmlReports"},
		strict=true,
		dryRun=false,
		monochrome = true
)
public class TestRunner {

}
