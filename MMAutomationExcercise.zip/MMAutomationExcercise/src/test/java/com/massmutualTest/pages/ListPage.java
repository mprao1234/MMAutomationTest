package com.massmutualTest.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.massmutualTest.commonlibrary.CommonFunctions;
import org.junit.Assert;

public class ListPage extends MMBasePage {

	public ListPage() {
		PageFactory.initElements(driver, this);
	}
	
	  @FindBy(id = "Page_link") private WebElement Pg_link;
	 

	@FindBy(id = "lbl_ttl_val")
	private WebElement TotalBalance;

	@FindBy(id = "txt_ttl_val")
	private WebElement TotalBalanceAmmount;

	@FindBy(xpath = "//*[Starts-with(@id,'txt_val'))")
	private List<WebElement> list_ValuesAmmount;

	@FindBy(xpath = "//*[Starts-with(@id,'lbl_val'))")
	private List<WebElement> Values;
	
	public void navigateToValuePage() {
		Pg_link.click();
	}

	public void verifyCountAndlabelsName(String validateData) {
		boolean flag = false;
		try {
			List<WebElement> list = Values;
			List<String> lablesText = new ArrayList<String>();
			for (int i = 0; i < list.size(); i++) {
				lablesText.add(list.get(i).getText().trim());
			}
			if(list.size()==lablesText.size()) {
				flag = CommonFunctions.compareListAndStringArrays(lablesText, validateData, ",");
				if (flag) {
					Reporter.log(" value Labels names are matching", true);
				} else {
					Reporter.log("value Labels names are not matching", false);
				}
			}else {
				Reporter.log("Expected count not present", false);
			}	
		} catch (Exception e) {
			Reporter.log("Lable count is not matching", false);
		}

	}

	/**
	 * following method is to verify all amount present in UI should be greater than zero
	 * @param Inputvalue
	 * @author Purushotham
	 */
	public void verifyValueGreaterthanZero(Integer Inputvalue) {
		try {
			List<WebElement> listAmount = list_ValuesAmmount;
			List<WebElement> listLabels = Values;
			for (int i = 0; i < listAmount.size(); i++) {
				if (Integer.parseInt(listAmount.get(i).getAttribute("value")) > Inputvalue.intValue()) {
					Assert.assertTrue("For Label=" + listLabels.get(i).getAttribute("name") + " Value is "
							+ listAmount.get(i).getAttribute("value") + "  is greater than 0 ", true);
				} else {
					Assert.assertTrue("For Label=" + listLabels.get(i).getAttribute("name") + " Value is "
							+ listAmount.get(i).getAttribute("value") + "  is not greater than 0 ", false);
				}
			}
		} catch (Exception e) {
			Reporter.log("Amount present in the given lable is not greater then 0", false);
		}
	}

	
	public void verifySumOfBalance() {
		try {
			List<WebElement> listvalue = list_ValuesAmmount;
			int totalValue = 0;
			for (WebElement elementlist: listvalue) {
				String amount = elementlist.getAttribute("value");
				String amountAfterReplace = CommonFunctions.replacevalue(amount,"$","");
				totalValue = totalValue + Integer.parseInt(amountAfterReplace);
			}
			String totalUIbalance = TotalBalanceAmmount.getAttribute("value");
			if (Integer.parseInt(totalUIbalance.replace("$", "")) == totalValue) {
				Assert.assertTrue("Total  value is " + totalValue + " instead of "
						+ Integer.parseInt(totalUIbalance.replace("$", "")), true);
			} else {
				Assert.assertTrue("Total  value is " + totalValue + " instead of "
						+ Integer.parseInt(totalUIbalance.replace("$", "")), false);
			}
		} catch (Exception e) {
			Reporter.log("Sum validation failed", false);
		}
	}

	
	public void CheckCurrencyFormat() {
		try {
			List<WebElement> listAmmount = list_ValuesAmmount;
			List<WebElement> listlabelsValue = Values;
			for (int i = 0; i < listAmmount.size(); i++) {
				if(listAmmount.get(i).getAttribute("value").contains("$")) {
					if (listAmmount.get(i).getAttribute("value").indexOf("$") == 0) {
						Assert.assertTrue("For Field=" + listlabelsValue.get(i).getAttribute("name") + " Value is "
								+ listAmmount.get(i).getAttribute("value") + "  is in US currency format ", true);
					} else {
						Assert.assertTrue("For Field=" + listlabelsValue.get(i).getAttribute("name") + " Value is "
								+ listAmmount.get(i).getAttribute("value") + "  is not in US currency format ", false);
					}
				}else {
					Reporter.log("$ sign is missing from the ammount", false);
				}
				
			}} catch (Exception e){
				Reporter.log("$ sign is missing from the ammount", false);
		}
	}
}
