package com.massmutualTest.pages;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import com.massmutualTest.utilities.WebDriverConfig;

public class MMBasePage extends WebDriverConfig {

	/**
	 * following method is for launching the browser and navigate to given URL
	 * @author Purushotham
	 */
	public void click_WebElement(WebElement element, String msg) {
		try {
			if (element.isDisplayed()) {
				element.click();
				Assert.assertTrue("User is able to click on" + msg + " successfully", true);
			} else {
				Assert.assertTrue("User is unable to click on" + msg + " webelement", false);
			}
		} catch (Exception e) {
			Reporter.log("User is unable to click on" + msg + " webelement", false);
		}
	}

	/**
	 * following method is for entering data into the WebElement
	 * @author Purushotham
	 */
	public void setData(WebElement element, String data, String msg) {
		try {
			if (element.isDisplayed()) {
				element.sendKeys(data);
				Assert.assertTrue("User is able to update the " + msg + " field successfully", true);
			} else {
				Assert.assertTrue("User is unable to update the " + msg + " successfully", false);
			}
		} catch (Exception e) {
			Reporter.log("User is unable to update the " + msg + " successfully", false);
		}
	}

}
