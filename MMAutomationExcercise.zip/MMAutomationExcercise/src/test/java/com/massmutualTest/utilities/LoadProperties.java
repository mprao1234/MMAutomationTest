package com.massmutualTest.utilities;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Properties;

import org.testng.Reporter;

public class LoadProperties{
	private Properties pro;
	private final String proFilePath = "config/application.properties";

	public LoadProperties() {
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(proFilePath));
			pro = new Properties();
			pro.load(reader);
			reader.close();
		} catch (Exception e) {
			Reporter.log("properties file is not found at " + proFilePath, false);
		}
	}

	
	public String getBrower() {
		String browser = pro.getProperty("browsername");
		try {
			if (browser != null) {
				Reporter.log("Browser name " + browser + "is available", true);
			} else {
				Reporter.log("Browser name is not available", false);
			}
		} catch (Exception e) {
			Reporter.log("Browser name is not available", false);
		}
		return browser;
	}

	
	public String getDriverPath() {
		String driverpath = pro.getProperty("driverpath");
		try {
			if (driverpath != null) {
				Reporter.log("Driver path " + driverpath + " is available", true);
			} else {
				Reporter.log("Driver path is not found", false);
			}
		} catch (Exception e) {
			Reporter.log("Driver path is not found", false);
		}
		return driverpath;
	}

	public String getApplicationUrl() {
		String appUrl = pro.getProperty("applicationUrl");
		try {
			if (appUrl != null) {
				Reporter.log("application Url " + appUrl + " is available", true);
			} else {
				Reporter.log("Application url is not found", false);
			}
		} catch (Exception e) {
			Reporter.log("Application url is not found", false);
		}
		return appUrl;
	}
	
	
	public String getScreenshotLocation() {
		String screenshotLocation = pro.getProperty("screenshotLoc");
		try {
			if (screenshotLocation != null) {
				Reporter.log("location " + screenshotLocation + " found", true);
			} else {
				Reporter.log("Location is not found", false);
			}
		} catch (Exception e) {
			Reporter.log("Location is not found", false);
		}
		return screenshotLocation;
	}
}
